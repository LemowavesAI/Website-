/* =========================================================
   FOOD AVENUE — JavaScript
   Preloader · Navbar · Reveal · Gallery Lightbox ·
   Menu Tabs · Tour Slider · Booking Form → WhatsApp
   ========================================================= */

(function () {
  'use strict';

  /* -------------------------------------------------------
     PRELOADER
  ------------------------------------------------------- */
  const preloader = document.getElementById('preloader');

  window.addEventListener('load', () => {
    setTimeout(() => {
      preloader.classList.add('is-hidden');
    }, 600);
  });


  /* -------------------------------------------------------
     NAVBAR — scroll shrink + mobile toggle
  ------------------------------------------------------- */
  const navbar    = document.getElementById('navbar');
  const navToggle = document.getElementById('navToggle');
  const navMenu   = document.getElementById('navMenu');

  const shrinkNav = () => {
    navbar.classList.toggle('is-scrolled', window.scrollY > 60);
  };
  window.addEventListener('scroll', shrinkNav, { passive: true });
  shrinkNav();

  navToggle.addEventListener('click', () => {
    const isOpen = navMenu.classList.toggle('is-open');
    navToggle.classList.toggle('is-active', isOpen);
    navToggle.setAttribute('aria-expanded', isOpen);
    document.body.style.overflow = isOpen ? 'hidden' : '';
  });

  // Close nav on link click
  navMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('is-open');
      navToggle.classList.remove('is-active');
      navToggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    });
  });

  // Close nav on outside click
  document.addEventListener('click', e => {
    if (navMenu.classList.contains('is-open') &&
        !navMenu.contains(e.target) &&
        !navToggle.contains(e.target)) {
      navMenu.classList.remove('is-open');
      navToggle.classList.remove('is-active');
      navToggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }
  });


  /* -------------------------------------------------------
     SCROLL REVEAL
  ------------------------------------------------------- */
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        // Stagger siblings inside the same parent
        const siblings = Array.from(
          entry.target.parentElement.querySelectorAll('.reveal')
        );
        const idx = siblings.indexOf(entry.target);
        entry.target.style.transitionDelay = `${idx * 0.07}s`;
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));


  /* -------------------------------------------------------
     GALLERY LIGHTBOX + VIEW ALL TOGGLE
  ------------------------------------------------------- */
  // All gallery items (including hidden extras)
  const allGalleryItems = Array.from(document.querySelectorAll('.gallery__item'));
  const lightbox     = document.getElementById('lightbox');
  const lightboxImg  = document.getElementById('lightboxImg');
  const lightboxCap  = document.getElementById('lightboxCaption');
  const lightboxClose = document.getElementById('lightboxClose');
  const lightboxPrev = document.getElementById('lightboxPrev');
  const lightboxNext = document.getElementById('lightboxNext');
  const galleryGrid  = document.getElementById('galleryGrid');
  const galleryToggle = document.getElementById('galleryToggle');

  let currentIndex    = 0;
  let galleryExpanded = false;

  const getVisibleItems = () => allGalleryItems.filter(i => i.style.display !== 'none');

  const openLightbox = (index) => {
    const visible = getVisibleItems();
    currentIndex = index;
    const item = visible[index];
    const img  = item.querySelector('img');
    const cap  = item.querySelector('figcaption');
    lightboxImg.src = img.src;
    lightboxImg.alt = img.alt;
    lightboxCap.textContent = cap ? cap.textContent : '';
    lightbox.classList.add('is-active');
    lightbox.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    lightboxClose.focus();
  };

  const closeLightbox = () => {
    lightbox.classList.remove('is-active');
    lightbox.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  };

  const prevImage = () => {
    const visible = getVisibleItems();
    currentIndex = (currentIndex - 1 + visible.length) % visible.length;
    openLightbox(currentIndex);
  };

  const nextImage = () => {
    const visible = getVisibleItems();
    currentIndex = (currentIndex + 1) % visible.length;
    openLightbox(currentIndex);
  };

  allGalleryItems.forEach((item, i) => {
    item.addEventListener('click', () => {
      const visible = getVisibleItems();
      const visIdx = visible.indexOf(item);
      if (visIdx !== -1) openLightbox(visIdx);
    });
    item.setAttribute('tabindex', '0');
    item.setAttribute('role', 'button');
    item.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const visible = getVisibleItems();
        const visIdx = visible.indexOf(item);
        if (visIdx !== -1) openLightbox(visIdx);
      }
    });
  });

  lightboxClose.addEventListener('click', closeLightbox);
  lightboxPrev.addEventListener('click',  prevImage);
  lightboxNext.addEventListener('click',  nextImage);
  lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });
  document.addEventListener('keydown', e => {
    if (!lightbox.classList.contains('is-active')) return;
    if (e.key === 'Escape')      closeLightbox();
    if (e.key === 'ArrowLeft')   prevImage();
    if (e.key === 'ArrowRight')  nextImage();
  });

  // View All toggle
  if (galleryToggle) {
    galleryToggle.addEventListener('click', () => {
      galleryExpanded = !galleryExpanded;
      const extras = document.querySelectorAll('.gallery__item--extra');

      if (galleryExpanded) {
        // Switch grid to 3-column masonry
        galleryGrid.style.gridTemplateColumns = 'repeat(3, 1fr)';
        galleryGrid.style.gridTemplateRows    = '';
        galleryGrid.querySelectorAll('.gallery__item').forEach((el, i) => {
          el.style.gridColumn = '';
          el.style.gridRow    = '';
        });
        extras.forEach(el => {
          el.style.display = '';
          el.style.gridRow = '';
          el.style.height  = '260px';
        });
        galleryToggle.textContent = 'Show Less';
        // Re-run reveal observer
        extras.forEach(el => {
          el.classList.add('reveal');
          revealObserver.observe(el);
        });
      } else {
        galleryGrid.style.gridTemplateColumns = '';
        galleryGrid.style.gridTemplateRows    = '';
        // Restore explicit placements from CSS
        allGalleryItems.forEach(el => {
          el.style.gridColumn = '';
          el.style.gridRow    = '';
          el.style.height     = '';
        });
        extras.forEach(el => { el.style.display = 'none'; });
        galleryToggle.textContent = 'See All Photos';
        window.scrollTo({ top: document.getElementById('gallery').offsetTop - 80, behavior: 'smooth' });
      }
    });
  }


  /* -------------------------------------------------------
     MENU TABS
  ------------------------------------------------------- */
  const tabs   = document.querySelectorAll('.menu__tab');
  const panels = document.querySelectorAll('.menu__panel');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => {
        t.classList.remove('is-active');
        t.setAttribute('aria-selected', 'false');
      });
      panels.forEach(p => p.classList.remove('is-active'));

      tab.classList.add('is-active');
      tab.setAttribute('aria-selected', 'true');
      const target = document.getElementById(`panel-${tab.dataset.tab}`);
      if (target) target.classList.add('is-active');
    });
  });


  /* -------------------------------------------------------
     TOUR SLIDER — crossfade
  ------------------------------------------------------- */
  const slides  = Array.from(document.querySelectorAll('.tour__slide'));
  const dotsEl  = document.getElementById('tourDots');
  const prevBtn = document.getElementById('tourPrev');
  const nextBtn = document.getElementById('tourNext');
  let   current = 0;
  let   autoTimer;

  // Build dots
  slides.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.setAttribute('aria-label', `Go to slide ${i + 1}`);
    if (i === 0) dot.classList.add('is-active');
    dot.addEventListener('click', () => goTo(i));
    dotsEl.appendChild(dot);
  });

  const dots = dotsEl.querySelectorAll('button');

  const goTo = (n) => {
    slides[current].classList.remove('is-active');
    dots[current].classList.remove('is-active');
    current = (n + slides.length) % slides.length;
    slides[current].classList.add('is-active');
    dots[current].classList.add('is-active');
  };

  const startAuto = () => {
    autoTimer = setInterval(() => goTo(current + 1), 4500);
  };

  const stopAuto = () => clearInterval(autoTimer);

  prevBtn.addEventListener('click', () => { stopAuto(); goTo(current - 1); startAuto(); });
  nextBtn.addEventListener('click', () => { stopAuto(); goTo(current + 1); startAuto(); });

  // Touch swipe on slider
  const track = document.getElementById('tourTrack');
  let touchX = 0;
  track.addEventListener('touchstart', e => { touchX = e.touches[0].clientX; }, { passive: true });
  track.addEventListener('touchend', e => {
    const diff = touchX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 40) {
      stopAuto();
      goTo(diff > 0 ? current + 1 : current - 1);
      startAuto();
    }
  });

  startAuto();

  // Pause on hover
  const tourSlider = document.getElementById('tourSlider');
  tourSlider.addEventListener('mouseenter', stopAuto);
  tourSlider.addEventListener('mouseleave', startAuto);


  /* -------------------------------------------------------
     BOOKING FORM → WhatsApp
  ------------------------------------------------------- */
  const bookingForm = document.getElementById('bookingForm');

  if (bookingForm) {
    // Set min date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('bCheckin').min  = today;
    document.getElementById('bCheckout').min = today;

    // Make checkout min = checkin date
    document.getElementById('bCheckin').addEventListener('change', function () {
      document.getElementById('bCheckout').min = this.value;
      if (document.getElementById('bCheckout').value < this.value) {
        document.getElementById('bCheckout').value = '';
      }
    });

    bookingForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const name     = this.name.value.trim();
      const phone    = this.phone.value.trim();
      const checkin  = this.checkin.value;
      const checkout = this.checkout.value;
      const guests   = this.guests.value;
      const room     = this.room.value;
      const message  = this.message.value.trim();

      const formatDate = (d) => {
        if (!d) return '—';
        const [y, m, day] = d.split('-');
        return `${day}/${m}/${y}`;
      };

      const lines = [
        `🏨 *Booking Enquiry — Food Avenue*`,
        ``,
        `👤 *Name:* ${name}`,
        `📱 *Phone:* ${phone}`,
        `📅 *Check-In:* ${formatDate(checkin)}`,
        `📅 *Check-Out:* ${formatDate(checkout)}`,
        `👥 *Guests:* ${guests}`,
        `🛏️ *Room Type:* ${room}`,
        message ? `📝 *Requests:* ${message}` : '',
      ].filter(Boolean).join('\n');

      const waURL = `https://wa.me/919939393232?text=${encodeURIComponent(lines)}`;
      window.open(waURL, '_blank', 'noopener,noreferrer');
    });
  }


  /* -------------------------------------------------------
     CONTACT FORM → WhatsApp
  ------------------------------------------------------- */
  const contactForm = document.getElementById('contactForm');

  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const name    = this.name.value.trim();
      const phone   = this.phone.value.trim();
      const message = this.message.value.trim();

      const lines = [
        `💬 *Message from Food Avenue website*`,
        ``,
        `👤 *Name:* ${name}`,
        `📱 *Phone:* ${phone}`,
        `📝 *Message:* ${message}`,
      ].join('\n');

      const waURL = `https://wa.me/919939393232?text=${encodeURIComponent(lines)}`;
      window.open(waURL, '_blank', 'noopener,noreferrer');
    });
  }


  /* -------------------------------------------------------
     FOOTER YEAR
  ------------------------------------------------------- */
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();


  /* -------------------------------------------------------
     ACTIVE NAV LINK on scroll (highlight current section)
  ------------------------------------------------------- */
  const sections  = document.querySelectorAll('section[id]');
  const navLinks  = document.querySelectorAll('.nav-link');

  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navLinks.forEach(link => {
          link.classList.toggle(
            'is-active',
            link.getAttribute('href') === `#${entry.target.id}`
          );
        });
      }
    });
  }, { rootMargin: '-40% 0px -55% 0px' });

  sections.forEach(s => sectionObserver.observe(s));


  /* -------------------------------------------------------
     SMOOTH IMAGE LOAD — fade in when decoded
  ------------------------------------------------------- */
  document.querySelectorAll('img[loading="lazy"]').forEach(img => {
    img.style.opacity = '0';
    img.style.transition = 'opacity .5s ease';
    if (img.complete) {
      img.style.opacity = '1';
    } else {
      img.addEventListener('load', () => { img.style.opacity = '1'; });
    }
  });

})();
